
  # Continuous Scroll Scrollytelling Hero

  This is a code bundle for Continuous Scroll Scrollytelling Hero. The original project is available at https://www.figma.com/design/oECzMf4fymo1ixoSQme7Og/Continuous-Scroll-Scrollytelling-Hero.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  