import { useEffect, useRef, useState } from 'react';
import { SourceCluster } from './components/SourceCluster';
import { AIEngine } from './components/AIEngine';
import { FilmStrip } from './components/FilmStrip';
import { ViralClips } from './components/ViralClips';
import { PlatformCluster } from './components/PlatformCluster';
import { ViewersCluster } from './components/ViewersCluster';
import { Dashboard } from './components/Dashboard';
import { LockedState } from './components/LockedState';
import { UnlockedState } from './components/UnlockedState';
import { VerifiedState } from './components/VerifiedState';
import { TournamentJoin } from './components/TournamentJoin';
import { LoopClosure } from './components/LoopClosure';
import { ConnectorPath } from './components/ConnectorPath';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (containerRef.current) {
        const scrollTop = window.scrollY;
        const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
        const progress = scrollTop / scrollHeight;
        setScrollProgress(progress);
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background grid */}
      <div className="fixed inset-0 pointer-events-none">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px)
            `,
            backgroundSize: '48px 48px',
          }}
        />
      </div>

      <div ref={containerRef} className="relative">
        {/* Center spine indicator */}
        <div className="fixed left-1/2 top-0 bottom-0 w-px bg-white/5 pointer-events-none" />

        {/* Main flow container */}
        <div className="max-w-7xl mx-auto px-8 py-32">
          
          {/* Chapter 1: Source Cluster */}
          <div className="relative mb-96" id="chapter-1">
            <SourceCluster scrollProgress={scrollProgress} chapterProgress={0} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.05} 
            endProgress={0.15}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 2: AI Engine */}
          <div className="relative mb-96" id="chapter-2">
            <AIEngine scrollProgress={scrollProgress} chapterProgress={0.15} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.2} 
            endProgress={0.28}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 3: Full Episode */}
          <div className="relative mb-96" id="chapter-3">
            <FilmStrip scrollProgress={scrollProgress} chapterProgress={0.28} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.33} 
            endProgress={0.38}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 4: Viral Clips */}
          <div className="relative mb-96" id="chapter-4">
            <ViralClips scrollProgress={scrollProgress} chapterProgress={0.38} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.43} 
            endProgress={0.48}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 5: Platform Distribution */}
          <div className="relative mb-96" id="chapter-5">
            <PlatformCluster scrollProgress={scrollProgress} chapterProgress={0.48} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.53} 
            endProgress={0.58}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 6: Viewers */}
          <div className="relative mb-96" id="chapter-6">
            <ViewersCluster scrollProgress={scrollProgress} chapterProgress={0.58} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.63} 
            endProgress={0.68}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 7: Dashboard */}
          <div className="relative mb-96" id="chapter-7">
            <Dashboard scrollProgress={scrollProgress} chapterProgress={0.68} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.73} 
            endProgress={0.76}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 8: Locked State */}
          <div className="relative mb-96" id="chapter-8">
            <LockedState scrollProgress={scrollProgress} chapterProgress={0.76} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.79} 
            endProgress={0.82}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 9: Unlocked State */}
          <div className="relative mb-96" id="chapter-9">
            <UnlockedState scrollProgress={scrollProgress} chapterProgress={0.82} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.85} 
            endProgress={0.88}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 10: Verified State */}
          <div className="relative mb-96" id="chapter-10">
            <VerifiedState scrollProgress={scrollProgress} chapterProgress={0.88} />
          </div>

          <ConnectorPath 
            scrollProgress={scrollProgress} 
            startProgress={0.91} 
            endProgress={0.94}
            fromPosition="center"
            toPosition="center"
          />

          {/* Chapter 11: Tournament Join */}
          <div className="relative mb-96" id="chapter-11">
            <TournamentJoin scrollProgress={scrollProgress} chapterProgress={0.94} />
          </div>

          {/* Loop Closure */}
          <div className="relative mb-32" id="loop">
            <LoopClosure scrollProgress={scrollProgress} chapterProgress={0.98} />
          </div>
        </div>
      </div>
    </div>
  );
}
