import { motion } from 'motion/react';
import { Lock } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface LockedStateProps {
  scrollProgress: number;
  chapterProgress: number;
}

export function LockedState({ scrollProgress, chapterProgress }: LockedStateProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <motion.div
          className="relative"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ 
            opacity: isFocused ? 1 : 0.6,
            scale: isFocused ? 1 : 0.95,
          }}
          transition={{
            duration: 0.6,
            ease: [0.16, 1, 0.3, 1],
          }}
        >
          {/* Lock container */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-12 backdrop-blur-sm flex flex-col items-center gap-6">
            <motion.div
              className="w-20 h-20 bg-white/10 border-2 border-white/20 rounded-2xl flex items-center justify-center"
              animate={{
                borderColor: isFocused ? 'rgba(255, 100, 100, 0.4)' : 'rgba(255, 255, 255, 0.2)',
              }}
            >
              <Lock size={36} className="text-white/60" strokeWidth={1.5} />
            </motion.div>

            <div className="text-center">
              <div className="text-white/90 tracking-wide mb-2">Browse mode locked</div>
              <div className="text-white/50 text-sm">Sign up to unlock interactions</div>
            </div>
          </div>
        </motion.div>
      </div>
    </Node>
  );
}