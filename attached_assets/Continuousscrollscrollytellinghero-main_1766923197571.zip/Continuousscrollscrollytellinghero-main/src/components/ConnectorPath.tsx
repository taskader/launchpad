import { motion } from 'motion/react';

interface ConnectorPathProps {
  scrollProgress: number;
  startProgress: number;
  endProgress: number;
  fromPosition?: 'left' | 'center' | 'right';
  toPosition?: 'left' | 'center' | 'right';
}

export function ConnectorPath({ 
  scrollProgress, 
  startProgress, 
  endProgress,
  fromPosition = 'center',
  toPosition = 'center',
}: ConnectorPathProps) {
  // Calculate if this path should be visible and animating
  const isActive = scrollProgress >= startProgress && scrollProgress <= endProgress;
  const pathProgress = isActive 
    ? Math.min(1, Math.max(0, (scrollProgress - startProgress) / (endProgress - startProgress)))
    : scrollProgress > endProgress ? 1 : 0;

  // Calculate positions for curved path
  const startX = fromPosition === 'left' ? 100 : fromPosition === 'right' ? 300 : 200;
  const endX = toPosition === 'left' ? 100 : toPosition === 'right' ? 300 : 200;

  return (
    <div className="relative h-32 flex items-center justify-center -my-40 pointer-events-none">
      <svg width="400" height="120" className="absolute">
        <defs>
          <linearGradient id="pathGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="rgba(0, 200, 255, 0.6)" />
            <stop offset="100%" stopColor="rgba(0, 200, 255, 0.2)" />
          </linearGradient>
          
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Main path */}
        <motion.path
          d={`M ${startX} 20 Q ${(startX + endX) / 2} 60, ${endX} 100`}
          fill="none"
          stroke="url(#pathGradient)"
          strokeWidth="2"
          strokeDasharray="8 4"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ 
            pathLength: pathProgress,
            opacity: isActive ? 0.6 : 0.3,
          }}
          transition={{
            pathLength: { duration: 0.5, ease: 'easeInOut' },
            opacity: { duration: 0.3 },
          }}
        />

        {/* Arrow head */}
        {pathProgress > 0.9 && (
          <motion.polygon
            points={`${endX},100 ${endX - 6},94 ${endX + 6},94`}
            fill="rgba(0, 200, 255, 0.6)"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          />
        )}

        {/* Traveling pulse dot */}
        {isActive && pathProgress > 0 && (
          <motion.circle
            r="5"
            fill="#00C8FF"
            filter="url(#glow)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <animateMotion
              dur="0s"
              fill="freeze"
              path={`M ${startX} 20 Q ${(startX + endX) / 2} 60, ${endX} 100`}
              keyPoints={`${pathProgress};${pathProgress}`}
              keyTimes="0;1"
            />
          </motion.circle>
        )}
      </svg>
    </div>
  );
}
