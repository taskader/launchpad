import { motion } from 'motion/react';
import { Brain } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface AIEngineProps {
  scrollProgress: number;
  chapterProgress: number;
}

export function AIEngine({ scrollProgress, chapterProgress }: AIEngineProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <div className="relative w-32 h-32 flex items-center justify-center">
          {/* Outer rotating ring */}
          {isFocused && (
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-cyan-500/30"
              animate={{ rotate: 360 }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: 'linear',
              }}
              style={{
                borderStyle: 'dashed',
                borderSpacing: '8px',
              }}
            />
          )}
          
          {/* Inner glow */}
          {isFocused && (
            <motion.div
              className="absolute inset-4 rounded-full bg-cyan-500/10 blur-xl"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.6, 0.3],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          )}

          {/* Main circle */}
          <motion.div
            className="relative w-24 h-24 rounded-full bg-white/5 border border-white/20 flex items-center justify-center backdrop-blur-sm"
            animate={{
              borderColor: isFocused ? 'rgba(0, 200, 255, 0.4)' : 'rgba(255, 255, 255, 0.2)',
            }}
          >
            <Brain size={40} className="text-white/90" strokeWidth={1.5} />
          </motion.div>
        </div>

        <div className="text-white/90 tracking-wide">AI engine</div>
      </div>
    </Node>
  );
}