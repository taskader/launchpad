import { motion } from 'motion/react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface FilmStripProps {
  scrollProgress: number;
  chapterProgress: number;
}

export function FilmStrip({ scrollProgress, chapterProgress }: FilmStripProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <div className="relative">
          {/* Film strip container */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              {/* Perforations left */}
              <div className="flex flex-col gap-2">
                {[...Array(4)].map((_, i) => (
                  <div key={`perf-l-${i}`} className="w-2 h-2 rounded-sm bg-white/20" />
                ))}
              </div>

              {/* Film frames */}
              <div className="flex gap-2">
                {[...Array(3)].map((_, i) => (
                  <div
                    key={`frame-${i}`}
                    className="w-24 h-32 bg-white/10 rounded-lg border border-white/20 flex items-center justify-center relative overflow-hidden"
                  >
                    {/* Scan line effect */}
                    {isFocused && (
                      <motion.div
                        className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
                        initial={{ top: 0 }}
                        animate={{ top: '100%' }}
                        transition={{
                          duration: 2,
                          delay: i * 0.3,
                          ease: 'linear',
                        }}
                      />
                    )}
                    <div className="w-12 h-12 bg-white/5 rounded" />
                  </div>
                ))}
              </div>

              {/* Perforations right */}
              <div className="flex flex-col gap-2">
                {[...Array(4)].map((_, i) => (
                  <div key={`perf-r-${i}`} className="w-2 h-2 rounded-sm bg-white/20" />
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="text-white/90 tracking-wide">Full episode (8–15 min)</div>
      </div>
    </Node>
  );
}