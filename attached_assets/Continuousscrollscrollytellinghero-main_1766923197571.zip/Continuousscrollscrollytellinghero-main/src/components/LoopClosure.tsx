import { motion } from 'motion/react';
import { RefreshCw } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface LoopClosureProps {
  scrollProgress: number;
  chapterProgress: number;
}

export function LoopClosure({ scrollProgress, chapterProgress }: LoopClosureProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <motion.div
          className="relative flex items-center gap-4"
          initial={{ opacity: 0 }}
          animate={{ 
            opacity: isFocused ? 1 : 0.4,
          }}
          transition={{
            duration: 0.6,
            ease: [0.16, 1, 0.3, 1],
          }}
        >
          {/* Loop icon */}
          <motion.div
            className="w-16 h-16 bg-white/5 border border-white/20 rounded-full flex items-center justify-center"
            animate={{
              rotate: isFocused ? 360 : 0,
            }}
            transition={{
              duration: 3,
              repeat: isFocused ? Infinity : 0,
              ease: 'linear',
            }}
          >
            <RefreshCw size={24} className="text-cyan-400/60" strokeWidth={1.5} />
          </motion.div>

          {/* Dotted curved path back */}
          <svg width="200" height="80" className="opacity-40">
            <motion.path
              d="M 0 40 Q 50 10, 100 40 T 200 40"
              fill="none"
              stroke="rgba(0, 200, 255, 0.3)"
              strokeWidth="2"
              strokeDasharray="6 6"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: isFocused ? 1 : 0 }}
              transition={{
                duration: 2,
                ease: 'easeInOut',
              }}
            />
            
            {/* Traveling pulse dot */}
            {isFocused && (
              <motion.circle
                r="4"
                fill="#00C8FF"
                initial={{ offsetDistance: '0%' }}
                animate={{ offsetDistance: '100%' }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: 'linear',
                }}
                style={{
                  offsetPath: 'path("M 0 40 Q 50 10, 100 40 T 200 40")',
                }}
              >
                <animateMotion
                  dur="2s"
                  repeatCount="indefinite"
                  path="M 0 40 Q 50 10, 100 40 T 200 40"
                />
              </motion.circle>
            )}
          </svg>
        </motion.div>

        <div className="text-center max-w-md">
          <div className="text-white/90 tracking-wide mb-2">Rewards turn users into advocates</div>
          <div className="text-white/40 text-sm">The ecosystem loops back to grow the community</div>
        </div>
      </div>
    </Node>
  );
}