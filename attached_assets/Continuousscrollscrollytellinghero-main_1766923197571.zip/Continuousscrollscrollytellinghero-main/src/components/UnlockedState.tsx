import { motion } from 'motion/react';
import { Unlock, MessageSquare, UserPlus, Award, User, Image } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface UnlockedStateProps {
  scrollProgress: number;
  chapterProgress: number;
}

const features = [
  { name: 'Comment', icon: MessageSquare },
  { name: 'Follow', icon: UserPlus },
  { name: 'Points', icon: Award },
  { name: 'Username', icon: User },
  { name: 'Avatar', icon: Image },
];

export function UnlockedState({ scrollProgress, chapterProgress }: UnlockedStateProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <motion.div
          className="relative"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ 
            opacity: isFocused ? 1 : 0.6,
            scale: isFocused ? 1 : 0.95,
          }}
          transition={{
            duration: 0.6,
            ease: [0.16, 1, 0.3, 1],
          }}
        >
          {/* Unlocked container */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-12 backdrop-blur-sm flex flex-col items-center gap-6">
            <motion.div
              className="w-20 h-20 bg-cyan-500/10 border-2 border-cyan-400/40 rounded-2xl flex items-center justify-center"
              initial={{ rotate: -90, scale: 0 }}
              animate={{
                rotate: isFocused ? 0 : -90,
                scale: isFocused ? 1 : 0,
              }}
              transition={{
                duration: 0.5,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <Unlock size={36} className="text-cyan-400" strokeWidth={1.5} />
            </motion.div>

            <div className="text-center mb-4">
              <div className="text-white/90 tracking-wide mb-2">Signup unlocks</div>
              <div className="text-white/50 text-sm">Community actions now available</div>
            </div>

            {/* Feature pills */}
            <div className="flex flex-wrap gap-3 justify-center max-w-md">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.name}
                  className="bg-white/10 border border-cyan-400/30 rounded-full px-4 py-2 flex items-center gap-2"
                  initial={{ opacity: 0, scale: 0, y: 10 }}
                  animate={{
                    opacity: isFocused ? 1 : 0,
                    scale: isFocused ? 1 : 0,
                    y: isFocused ? 0 : 10,
                  }}
                  transition={{
                    delay: isFocused ? 0.2 + index * 0.1 : 0,
                    duration: 0.4,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <feature.icon size={14} className="text-cyan-400" strokeWidth={2} />
                  <span className="text-white/80 text-sm">{feature.name}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </Node>
  );
}