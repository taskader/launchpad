import { motion } from 'motion/react';
import { MessageCircle, Hash, MessageSquare, Play } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface SourceClusterProps {
  scrollProgress: number;
  chapterProgress: number;
}

const sources = [
  { name: 'Reddit', icon: MessageCircle, color: '#FF4500' },
  { name: 'X', icon: Hash, color: '#000000' },
  { name: 'Discord', icon: MessageSquare, color: '#5865F2' },
  { name: 'YouTube', icon: Play, color: '#FF0000' },
];

export function SourceCluster({ scrollProgress, chapterProgress }: SourceClusterProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-8">
        <div className="text-white/60 tracking-wide text-sm">SOURCES</div>
        <div className="grid grid-cols-2 gap-4">
          {sources.map((source, index) => (
            <motion.div
              key={source.name}
              className="relative bg-white/5 border border-white/10 rounded-2xl px-6 py-4 flex items-center gap-3 backdrop-blur-sm"
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: isFocused ? 1 : 0.5,
                y: 0,
              }}
              transition={{ 
                delay: isFocused ? index * 0.1 : 0,
                duration: 0.5,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              {/* Pulse animation */}
              {isFocused && (
                <motion.div
                  className="absolute -right-2 -top-2 w-3 h-3 rounded-full bg-cyan-400"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [1, 0.3, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: index * 0.2,
                  }}
                />
              )}
              <div className="w-6 h-6 text-white/80 flex items-center justify-center">
                <source.icon size={20} strokeWidth={1.5} />
              </div>
              <span className="text-white/90 text-sm">{source.name}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </Node>
  );
}