import { motion } from 'motion/react';
import { User } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface ViewersClusterProps {
  scrollProgress: number;
  chapterProgress: number;
}

export function ViewersCluster({ scrollProgress, chapterProgress }: ViewersClusterProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Create a crowd of viewer dots
  const viewerCount = 16;
  const viewers = Array.from({ length: viewerCount }, (_, i) => ({
    id: i,
    x: (i % 4) * 32,
    y: Math.floor(i / 4) * 32,
  }));

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <div className="text-white/90 tracking-wide">Viewers</div>
        
        <div className="relative bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm">
          <div className="relative w-32 h-32">
            {viewers.map((viewer, index) => (
              <motion.div
                key={viewer.id}
                className="absolute w-6 h-6 bg-white/20 border border-white/30 rounded-full flex items-center justify-center"
                style={{
                  left: viewer.x,
                  top: viewer.y,
                }}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ 
                  opacity: isFocused ? 1 : 0.5,
                  scale: isFocused ? 1 : 0.8,
                  x: isFocused ? Math.sin(index * 0.5) * 2 : 0,
                  y: isFocused ? Math.cos(index * 0.5) * 2 : 0,
                }}
                transition={{
                  delay: index * 0.03,
                  duration: 0.4,
                  ease: [0.16, 1, 0.3, 1],
                  x: {
                    duration: 2,
                    repeat: Infinity,
                    repeatType: 'reverse',
                    ease: 'easeInOut',
                  },
                  y: {
                    duration: 2,
                    repeat: Infinity,
                    repeatType: 'reverse',
                    ease: 'easeInOut',
                  },
                }}
              >
                <User size={12} className="text-white/60" strokeWidth={2} />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Node>
  );
}