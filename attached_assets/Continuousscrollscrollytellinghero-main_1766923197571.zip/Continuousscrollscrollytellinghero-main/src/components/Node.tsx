import { motion } from 'motion/react';
import { ReactNode, useEffect, useRef, useState } from 'react';

interface NodeProps {
  children: ReactNode;
  scrollProgress: number;
  chapterProgress: number;
  className?: string;
  position?: 'left' | 'center' | 'right';
}

export function Node({ children, scrollProgress, chapterProgress, className = '', position = 'center' }: NodeProps) {
  const [focusState, setFocusState] = useState<'past' | 'focused' | 'future'>('future');
  const nodeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!nodeRef.current) return;

      const rect = nodeRef.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      
      // Calculate distance from viewport center
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25; // 25% of viewport height

      if (distanceFromCenter < threshold) {
        // Node is centered in viewport
        setFocusState('focused');
      } else if (nodeCenter < viewportCenter) {
        // Node is above center (scrolled past)
        setFocusState('past');
      } else {
        // Node is below center (not reached yet)
        setFocusState('future');
      }
    };

    handleScroll(); // Initial check
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const opacity = focusState === 'focused' ? 1 : focusState === 'past' ? 0.25 : 0.4;
  const scale = focusState === 'focused' ? 1.02 : 1.0;
  const glow = focusState === 'focused';

  const positionClass = 
    position === 'left' ? 'mr-auto ml-0' :
    position === 'right' ? 'ml-auto mr-0' :
    'mx-auto';

  return (
    <motion.div
      ref={nodeRef}
      className={`relative ${positionClass} ${className}`}
      animate={{
        opacity,
        scale,
      }}
      transition={{
        duration: 0.6,
        ease: [0.16, 1, 0.3, 1],
      }}
    >
      {glow && (
        <motion.div
          className="absolute inset-0 rounded-3xl blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(0, 200, 255, 0.12) 0%, transparent 70%)',
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4 }}
        />
      )}
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
}