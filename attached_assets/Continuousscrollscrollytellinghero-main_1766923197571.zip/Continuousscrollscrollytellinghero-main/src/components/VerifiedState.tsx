import { motion } from 'motion/react';
import { BadgeCheck, TrendingUp, Gift, Star } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface VerifiedStateProps {
  scrollProgress: number;
  chapterProgress: number;
}

const benefits = [
  { name: 'Higher limits', icon: TrendingUp },
  { name: 'Bigger rewards', icon: Gift },
  { name: 'Status badge', icon: Star },
];

export function VerifiedState({ scrollProgress, chapterProgress }: VerifiedStateProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <motion.div
          className="relative"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ 
            opacity: isFocused ? 1 : 0.6,
            scale: isFocused ? 1 : 0.95,
          }}
          transition={{
            duration: 0.6,
            ease: [0.16, 1, 0.3, 1],
          }}
        >
          {/* Verified container */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-12 backdrop-blur-sm flex flex-col items-center gap-6">
            <motion.div
              className="relative w-20 h-20 bg-cyan-500/10 border-2 border-cyan-400/40 rounded-2xl flex items-center justify-center"
              initial={{ scale: 0, rotate: -180 }}
              animate={{
                scale: isFocused ? 1 : 0,
                rotate: isFocused ? 0 : -180,
              }}
              transition={{
                duration: 0.6,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              {/* Stamp effect */}
              {isFocused && (
                <motion.div
                  className="absolute inset-0 bg-cyan-400/20 rounded-2xl"
                  initial={{ scale: 1.5, opacity: 1 }}
                  animate={{ scale: 1, opacity: 0 }}
                  transition={{
                    duration: 0.6,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                />
              )}
              <BadgeCheck size={36} className="text-cyan-400" strokeWidth={1.5} fill="rgba(0, 200, 255, 0.2)" />
            </motion.div>

            <div className="text-center mb-4">
              <div className="text-white/90 tracking-wide mb-2">Verified unlocks full access</div>
              <div className="text-white/50 text-sm">Premium features activated</div>
            </div>

            {/* Benefit chips */}
            <div className="flex gap-3 justify-center">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={benefit.name}
                  className="bg-white/10 border border-cyan-400/30 rounded-full px-3 py-1.5 flex items-center gap-2"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{
                    opacity: isFocused ? 1 : 0,
                    y: isFocused ? 0 : 10,
                  }}
                  transition={{
                    delay: isFocused ? 0.3 + index * 0.1 : 0,
                    duration: 0.4,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <benefit.icon size={12} className="text-cyan-400" strokeWidth={2} />
                  <span className="text-white/80 text-xs">{benefit.name}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </Node>
  );
}