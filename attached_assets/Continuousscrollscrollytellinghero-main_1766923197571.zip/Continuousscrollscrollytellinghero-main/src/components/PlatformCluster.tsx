import { motion } from 'motion/react';
import { Hash, Play, Camera, Share2, MessageCircle, MessageSquare, Music } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface PlatformClusterProps {
  scrollProgress: number;
  chapterProgress: number;
}

const platforms = [
  { name: 'X', icon: Hash },
  { name: 'YouTube', icon: Play },
  { name: 'Instagram', icon: Camera },
  { name: 'Facebook', icon: Share2 },
  { name: 'Reddit', icon: MessageCircle },
  { name: 'Discord', icon: MessageSquare },
  { name: 'TikTok', icon: Music },
  { name: 'Bluesky', icon: Share2 },
];

export function PlatformCluster({ scrollProgress, chapterProgress }: PlatformClusterProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <div className="text-white/90 tracking-wide">Publish everywhere</div>
        
        <div className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm">
          <div className="grid grid-cols-4 gap-4">
            {platforms.map((platform, index) => (
              <motion.div
                key={platform.name}
                className="relative w-16 h-16 bg-white/10 border border-white/20 rounded-2xl flex flex-col items-center justify-center gap-1 group"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ 
                  opacity: isFocused ? 1 : 0.5,
                  scale: isFocused ? 1 : 0.95,
                }}
                transition={{
                  delay: isFocused ? index * 0.05 : 0,
                  duration: 0.3,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                {/* Pulse dot showing data arriving */}
                {isFocused && (
                  <motion.div
                    className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-cyan-400"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ 
                      scale: [0, 1.5, 1],
                      opacity: [0, 1, 1],
                    }}
                    transition={{
                      delay: index * 0.05,
                      duration: 0.4,
                    }}
                  />
                )}

                <platform.icon size={20} className="text-white/80" strokeWidth={1.5} />
                <span className="text-white/60 text-[10px] tracking-wide">{platform.name}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Node>
  );
}