import { motion } from 'motion/react';
import { Trophy, Share2 } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface TournamentJoinProps {
  scrollProgress: number;
  chapterProgress: number;
}

const divisions = [
  { name: 'Raider', color: '#FFD700', progress: 0.9 },
  { name: 'Crusader', color: '#C0C0C0', progress: 0.6 },
  { name: 'Elevator', color: '#CD7F32', progress: 0.3 },
];

export function TournamentJoin({ scrollProgress, chapterProgress }: TournamentJoinProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-8">
        {/* CTA Button */}
        <motion.button
          className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-8 py-4 rounded-full flex items-center gap-3 border border-cyan-400/50 shadow-lg shadow-cyan-500/20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ 
            opacity: isFocused ? 1 : 0.6,
            y: 0,
          }}
          transition={{
            duration: 0.6,
            ease: [0.16, 1, 0.3, 1],
          }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
        >
          <Trophy size={20} strokeWidth={2} />
          <span className="tracking-wide">Join tournament</span>
        </motion.button>

        {/* Divisions ladder */}
        <motion.div
          className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm w-80"
          initial={{ opacity: 0, y: 20 }}
          animate={{ 
            opacity: isFocused ? 1 : 0.6,
            y: 0,
          }}
          transition={{
            duration: 0.6,
            delay: 0.2,
            ease: [0.16, 1, 0.3, 1],
          }}
        >
          <div className="text-white/60 text-sm mb-6 text-center tracking-wide">DIVISIONS</div>
          
          <div className="space-y-4">
            {divisions.map((division, index) => (
              <motion.div
                key={division.name}
                className="relative"
                initial={{ opacity: 0, x: -20 }}
                animate={{
                  opacity: isFocused ? 1 : 0.5,
                  x: 0,
                }}
                transition={{
                  delay: isFocused ? 0.3 + index * 0.1 : 0,
                  duration: 0.5,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white/90 text-sm">{division.name}</span>
                  <span className="text-white/60 text-xs">{Math.round(division.progress * 100)}%</span>
                </div>
                
                {/* Progress bar */}
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{
                      background: `linear-gradient(to right, ${division.color}, ${division.color}dd)`,
                    }}
                    initial={{ width: 0 }}
                    animate={{
                      width: isFocused ? `${division.progress * 100}%` : 0,
                    }}
                    transition={{
                      delay: isFocused ? 0.5 + index * 0.15 : 0,
                      duration: 0.8,
                      ease: [0.16, 1, 0.3, 1],
                    }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Social share icons */}
        {isFocused && (
          <div className="flex gap-3">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-8 h-8 bg-white/10 border border-white/20 rounded-full flex items-center justify-center"
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{
                  delay: 0.8 + i * 0.1,
                  duration: 0.3,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                <Share2 size={12} className="text-white/60" strokeWidth={2} />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </Node>
  );
}