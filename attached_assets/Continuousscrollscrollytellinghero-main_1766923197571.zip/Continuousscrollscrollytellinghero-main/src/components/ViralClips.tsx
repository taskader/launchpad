import { motion } from 'motion/react';
import { Scissors } from 'lucide-react';
import { Node } from './Node';
import { useEffect, useRef, useState } from 'react';

interface ViralClipsProps {
  scrollProgress: number;
  chapterProgress: number;
}

export function ViralClips({ scrollProgress, chapterProgress }: ViralClipsProps) {
  const [isFocused, setIsFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const viewportCenter = window.innerHeight / 2;
      const nodeCenter = rect.top + rect.height / 2;
      const distanceFromCenter = Math.abs(nodeCenter - viewportCenter);
      const threshold = window.innerHeight * 0.25;
      setIsFocused(distanceFromCenter < threshold);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Node scrollProgress={scrollProgress} chapterProgress={chapterProgress} position="center">
      <div ref={ref} className="flex flex-col items-center gap-6">
        <div className="relative">
          {/* Film strip with highlights */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              {/* Perforations left */}
              <div className="flex flex-col gap-2">
                {[...Array(4)].map((_, i) => (
                  <div key={`perf-l-${i}`} className="w-2 h-2 rounded-sm bg-white/20" />
                ))}
              </div>

              {/* Film frames with viral highlights */}
              <div className="flex gap-2">
                {[...Array(5)].map((_, i) => {
                  const isHighlighted = i === 1 || i === 3;
                  return (
                    <motion.div
                      key={`frame-${i}`}
                      className={`w-20 h-28 bg-white/10 rounded-lg flex items-center justify-center relative overflow-hidden ${
                        isHighlighted ? 'border-2 border-cyan-400/60' : 'border border-white/20'
                      }`}
                      animate={{
                        borderColor: isHighlighted && isFocused ? 'rgba(0, 200, 255, 0.8)' : undefined,
                      }}
                    >
                      {/* Glow for highlighted frames */}
                      {isHighlighted && isFocused && (
                        <motion.div
                          className="absolute inset-0 bg-cyan-400/10 rounded-lg"
                          animate={{
                            opacity: [0.3, 0.6, 0.3],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            delay: i * 0.2,
                          }}
                        />
                      )}

                      {/* Scissors icon appears on highlighted frames */}
                      {isHighlighted && isFocused && (
                        <motion.div
                          className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-cyan-500 flex items-center justify-center"
                          initial={{ scale: 0, rotate: -180 }}
                          animate={{ scale: 1, rotate: 0 }}
                          transition={{
                            delay: 0.3 + i * 0.2,
                            duration: 0.4,
                            ease: [0.16, 1, 0.3, 1],
                          }}
                        >
                          <Scissors size={14} className="text-black" strokeWidth={2} />
                        </motion.div>
                      )}

                      <div className="w-10 h-10 bg-white/5 rounded" />
                    </motion.div>
                  );
                })}
              </div>

              {/* Perforations right */}
              <div className="flex flex-col gap-2">
                {[...Array(4)].map((_, i) => (
                  <div key={`perf-r-${i}`} className="w-2 h-2 rounded-sm bg-white/20" />
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="text-white/90 tracking-wide">Viral clips</div>
      </div>
    </Node>
  );
}